Deploy:
1. New > Web Service > Upload ZIP
2. Build Command: npm install
3. Start Command: npm start
4. Port: 10000
